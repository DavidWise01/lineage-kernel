// fused_observer_runtime.js
// PCK Fused Six Observer Runtime

export class FusedObserverRuntime {
  constructor() {
    this.cycle = 0;

    // 5-body continuity core
    this.core = {
      left:  new Uint8Array(4).fill(0),
      right: new Uint8Array(4).fill(0),
      bridge: new Uint8Array(8).fill(0)
    };

    // 6th observer
    this.observer = {
      position: 'outside',
      choices: 0,
      lastChoice: null,
      grounded: false
    };

    this.lineage = [];
    this.orphans = [];
  }

  hash(input) {
    const h = new Uint8Array(4);
    if (!input) return h;
    const s = String(input);

    for (let i = 0; i < s.length; i++) {
      h[i % 4] = (h[i % 4] + s.charCodeAt(i)) & 0xFF;
    }

    return h;
  }

  balance(leftInput, rightInput) {
    const leftHash = this.hash(leftInput);
    const rightHash = this.hash(rightInput);

    for (let i = 0; i < 4; i++) {
      this.core.bridge[i] =
        (this.core.bridge[i] + leftHash[i] + 255) & 0xFF;
    }

    for (let i = 4; i < 8; i++) {
      this.core.bridge[i] =
        (this.core.bridge[i] + rightHash[i - 4]) & 0xFF;
    }

    const left =
      (this.core.bridge[0] +
       this.core.bridge[1] +
       this.core.bridge[2] +
       this.core.bridge[3]) - 512;

    const right =
      (this.core.bridge[4] +
       this.core.bridge[5] +
       this.core.bridge[6] +
       this.core.bridge[7]) - 512;

    return (left + right) / 1024;
  }

  choose(balance, context = '') {
    this.observer.choices++;

    const isBalanced = Math.abs(balance) < 0.01;
    const exploratory =
      context.includes('crypto') ||
      context.includes('explore');

    if (this.observer.choices % 10000 === 0) {
      return {
        action: 'ground',
        reason: 'observer chose recount'
      };
    }

    if (isBalanced && exploratory) {
      return {
        action: 'continue',
        reason: 'balanced but exploration continues'
      };
    }

    if (!isBalanced && exploratory) {
      return {
        action: 'let_tilt',
        reason: 'observer allows bounded imbalance exploration'
      };
    }

    return {
      action: 'maintain',
      reason: 'continuity safety baseline'
    };
  }

  ground() {
    this.core.bridge.fill(0);
    this.observer.grounded = true;

    return {
      action: 'ground',
      reason: 'continuity recount'
    };
  }

  healOrphan(seed) {
    if (!seed?.source) {
      return {
        decision: 'REJECT',
        reason: 'missing lineage'
      };
    }

    if (seed.private === true) {
      return {
        decision: 'QUARANTINE',
        reason: 'private boundary uncertain'
      };
    }

    this.orphans.push(seed);

    return {
      decision: 'REATTACH',
      reason: 'lineage verified'
    };
  }

  propagate(seed) {
    const choice = this.choose(0, seed.context || '');

    if (choice.action === 'ground') {
      return this.ground();
    }

    if (choice.action === 'maintain') {
      this.lineage.push(seed);
      return {
        decision: 'ALLOW',
        reason: 'observer approved continuity'
      };
    }

    if (choice.action === 'let_tilt') {
      return {
        decision: 'DEFER',
        reason: 'exploration still unfolding'
      };
    }

    return {
      decision: 'OBSERVE',
      reason: choice.reason
    };
  }

  step(left, right, context = '') {
    this.cycle++;

    const balance = this.balance(left, right);
    const choice = this.choose(balance, context);

    this.observer.lastChoice = choice;

    if (choice.action === 'continue') {
      this.core.bridge[0] =
        (this.core.bridge[0] + 1) & 0xFF;
    }

    for (let i = 0; i < 8; i++) {
      this.core.bridge[i] =
        (this.core.bridge[i] * 1664525 + 1013904223) & 0xFF;
    }

    return {
      cycle: this.cycle,
      balance,
      choice,
      bridge: Array.from(this.core.bridge),
      observer: this.observer
    };
  }
}

export default FusedObserverRuntime;
