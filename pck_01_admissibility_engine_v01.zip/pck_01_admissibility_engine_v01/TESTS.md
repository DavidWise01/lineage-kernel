# Test Notes

Expected demo decision:

```text
ALLOW
```

Because:
- root exists
- intent is known
- energy is bounded
- phase is burrow
- burrow intent is compatible with burrow phase
- delta is within 0.00000001
- private visibility does not leak
