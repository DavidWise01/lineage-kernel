# PCK 01/10 — Admissibility Engine v0.1

## Stack Position

```text
01/10 = ADMISSIBILITY
```

This is the first formal continuity component after containment/continuity theory.

It answers one question:

```text
Does this proposed transition still count as SELF?
```

---

## Core Law

```text
Not all transitions preserve identity.
```

A state may persist only if the transition is admissible.

---

## Input

```json
{
  "previous_root": "...",
  "state": {
    "energy": 0.72,
    "accumulator": 0.12,
    "current_node": 3,
    "step_count": 41,
    "bridge_state": [0,0,0,0,0,0,0,0]
  },
  "transition": {
    "intent": "mutate|preserve|heal|gather|burrow|protect|propagate|publish",
    "delta": 0.00000001,
    "visibility": "private|shared|public",
    "payload": {}
  },
  "observer": {
    "choice": "continue|maintain|let_tilt|ground|defer"
  }
}
```

---

## Output

```json
{
  "admissible": true,
  "decision": "ALLOW|DENY|QUARANTINE|DEFER|HEAL",
  "reason": "...",
  "new_root": "...",
  "checks": {}
}
```

---

## What It Checks

1. root continuity exists
2. delta is within limit
3. energy phase permits intent
4. bridge state is bounded
5. private data does not leak public
6. observer choice does not contradict transition
7. healing transitions can bypass normal mutation limits only to repair
8. root witness updates deterministically

---

## Run Demo

```bash
python admissibility_engine.py demo
```

## Validate JSON

```bash
python admissibility_engine.py check examples/example_transition.json
```

---

## Continuity Stack Roadmap

```text
01/10 Admissibility Engine
02/10 Root Witness
03/10 Reactive Shell Integration
04/10 Orphan Stitch/Heal
05/10 Six-Body Observer Hook
06/10 Seven-Body Verifier
07/10 Eight-Body Executor
08/10 Recursive Nest Wind/Unwind
09/10 Responsible Propagator
10/10 Self-Persistent Seed OS
```
