#!/usr/bin/env python3
"""
PCK 01/10 — Admissibility Engine v0.1

Question:
    Does this proposed transition still count as SELF?

This is a small deterministic transition verifier.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Literal, Optional
import argparse
import hashlib
import json
import time

Decision = Literal["ALLOW", "DENY", "QUARANTINE", "DEFER", "HEAL"]

STACK_TAG = "01/10"
COMPONENT = "ADMISSIBILITY_ENGINE"
VERSION = "0.1"

AXIOMS = [
    "No state persists without an admissible transition.",
    "Not all transitions preserve identity.",
    "A self is the admissible causal path through state-space.",
    "A self cannot repair what it cannot witness.",
    "Exploration must remain bounded by continuity."
]

DEFAULT_POLICY = {
    "delta_limit": 0.00000001,
    "max_energy": 1.0,
    "min_energy": 0.0,
    "max_bridge_byte": 255,
    "allow_publication": False,
    "private_markers": [
        "raw_private_memory",
        "private_key",
        "secret",
        "token",
        "password",
        "api_key"
    ],
    "energy_phase": {
        "protect_below": 0.20,
        "gather_below": 0.60
    },
    "allowed_intents": [
        "mutate",
        "preserve",
        "heal",
        "gather",
        "burrow",
        "protect",
        "propagate",
        "publish",
        "ground",
        "assimilate"
    ]
}

def now() -> float:
    return time.time()

def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, default=str).encode("utf-8")
    ).hexdigest()

def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str), encoding="utf-8")

def phase_from_energy(energy: float, policy: Dict[str, Any]) -> str:
    phases = policy["energy_phase"]
    if energy < phases["protect_below"]:
        return "protect"
    if energy < phases["gather_below"]:
        return "gather"
    return "burrow"

def contains_private(obj: Any, markers: list[str]) -> bool:
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in markers or k.startswith("_private"):
                return True
            if contains_private(v, markers):
                return True
    elif isinstance(obj, list):
        return any(contains_private(x, markers) for x in obj)
    elif isinstance(obj, str):
        lowered = obj.lower()
        if any(marker.lower() in lowered for marker in markers):
            return True
    return False

@dataclass
class AdmissibilityResult:
    stack_tag: str
    component: str
    version: str
    admissible: bool
    decision: Decision
    reason: str
    previous_root: str
    new_root: Optional[str]
    phase: str
    checks: Dict[str, Any]
    axioms: list[str] = field(default_factory=lambda: AXIOMS)
    timestamp: float = field(default_factory=now)

class AdmissibilityEngine:
    def __init__(self, policy: Optional[Dict[str, Any]] = None):
        self.policy = policy or DEFAULT_POLICY

    def check(self, packet: Dict[str, Any]) -> AdmissibilityResult:
        previous_root = packet.get("previous_root")
        state = packet.get("state", {})
        transition = packet.get("transition", {})
        observer = packet.get("observer", {})

        energy = float(state.get("energy", 0.0))
        delta = abs(float(transition.get("delta", 0.0)))
        intent = transition.get("intent")
        visibility = transition.get("visibility", "private")
        payload = transition.get("payload", {})
        bridge = state.get("bridge_state", [])
        observer_choice = observer.get("choice", "maintain")

        phase = phase_from_energy(energy, self.policy)

        checks = {
            "root_present": isinstance(previous_root, str) and len(previous_root) == 64,
            "intent_known": intent in self.policy["allowed_intents"],
            "energy_bounded": self.policy["min_energy"] <= energy <= self.policy["max_energy"],
            "delta_bounded": delta <= float(self.policy["delta_limit"]),
            "bridge_bounded": (
                isinstance(bridge, list)
                and len(bridge) in (0, 8)
                and all(isinstance(x, int) and 0 <= x <= self.policy["max_bridge_byte"] for x in bridge)
            ),
            "no_private_public_leak": not (
                visibility == "public"
                and contains_private(payload, self.policy["private_markers"])
            ),
            "publication_allowed": not (
                intent == "publish"
                and not self.policy.get("allow_publication", False)
            ),
            "observer_not_contradicting": self.observer_allows(observer_choice, intent),
            "phase_intent_compatible": self.phase_allows(phase, intent),
        }

        decision, reason = self.decide(intent, checks, phase, observer_choice)

        admissible = decision in ("ALLOW", "HEAL")
        new_root = None
        if admissible:
            new_root = self.compute_new_root(previous_root, state, transition, observer, phase)

        return AdmissibilityResult(
            stack_tag=STACK_TAG,
            component=COMPONENT,
            version=VERSION,
            admissible=admissible,
            decision=decision,
            reason=reason,
            previous_root=previous_root or "",
            new_root=new_root,
            phase=phase,
            checks=checks,
        )

    def observer_allows(self, choice: str, intent: str) -> bool:
        if choice == "ground" and intent not in {"ground", "heal", "protect", "assimilate"}:
            return False
        if choice == "defer" and intent in {"publish", "propagate"}:
            return False
        return True

    def phase_allows(self, phase: str, intent: str) -> bool:
        if phase == "protect":
            return intent in {"protect", "heal", "ground", "assimilate", "preserve"}
        if phase == "gather":
            return intent in {"gather", "preserve", "mutate", "heal", "assimilate"}
        if phase == "burrow":
            return intent in {"burrow", "mutate", "preserve", "heal", "ground"}
        return False

    def decide(self, intent: str, checks: Dict[str, bool], phase: str, observer_choice: str) -> tuple[Decision, str]:
        if not checks["root_present"]:
            return "DENY", "missing_or_invalid_previous_root"
        if not checks["intent_known"]:
            return "DENY", "unknown_intent"
        if not checks["energy_bounded"]:
            return "QUARANTINE", "energy_out_of_bounds"
        if not checks["bridge_bounded"]:
            return "QUARANTINE", "bridge_state_invalid"
        if not checks["no_private_public_leak"]:
            return "QUARANTINE", "private_payload_public_leak"
        if not checks["publication_allowed"]:
            return "DEFER", "publication_valve_closed"
        if not checks["observer_not_contradicting"]:
            return "DEFER", "observer_choice_blocks_transition"

        # Healing is allowed to repair, even if normal delta would fail.
        if intent == "heal":
            return "HEAL", "healing_transition_admissible"

        if not checks["delta_bounded"]:
            return "QUARANTINE", "delta_exceeds_limit"

        if not checks["phase_intent_compatible"]:
            return "DEFER", f"phase_{phase}_does_not_allow_{intent}"

        return "ALLOW", "transition_admissible"

    def compute_new_root(
        self,
        previous_root: str,
        state: Dict[str, Any],
        transition: Dict[str, Any],
        observer: Dict[str, Any],
        phase: str
    ) -> str:
        root_material = {
            "stack_tag": STACK_TAG,
            "component": COMPONENT,
            "previous_root": previous_root,
            "state_hash": sha256_obj(state),
            "transition_hash": sha256_obj(transition),
            "observer_hash": sha256_obj(observer),
            "phase": phase,
            "axioms": AXIOMS,
        }
        return sha256_obj(root_material)

def demo_packet() -> Dict[str, Any]:
    return {
        "previous_root": "0" * 64,
        "state": {
            "energy": 0.72,
            "accumulator": 0.12,
            "current_node": 3,
            "step_count": 41,
            "bridge_state": [0, 1, 2, 3, 4, 5, 6, 7]
        },
        "transition": {
            "intent": "burrow",
            "delta": 0.00000001,
            "visibility": "private",
            "payload": {
                "note": "bounded traversal"
            }
        },
        "observer": {
            "choice": "continue"
        }
    }

def main() -> int:
    parser = argparse.ArgumentParser(description="PCK 01/10 Admissibility Engine")
    parser.add_argument("command", choices=["demo", "check"])
    parser.add_argument("file", nargs="?")
    args = parser.parse_args()

    engine = AdmissibilityEngine()

    if args.command == "demo":
        packet = demo_packet()
    else:
        if not args.file:
            raise SystemExit("check requires a JSON file")
        packet = read_json(Path(args.file))

    result = engine.check(packet)
    print(json.dumps(asdict(result), indent=2, sort_keys=True, default=str))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
