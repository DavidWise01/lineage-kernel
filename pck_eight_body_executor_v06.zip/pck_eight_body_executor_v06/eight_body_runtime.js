// eight_body_runtime.js
// PCK v0.6 — Body 8 executor / propagator

import crypto from 'crypto';

function stableStringify(obj) {
  return JSON.stringify(obj, Object.keys(obj).sort());
}

function sha256(obj) {
  return crypto.createHash('sha256')
    .update(stableStringify(obj))
    .digest('hex');
}

export class EightBodyRuntime {
  constructor() {
    this.cycle = 0;

    this.body5 = {
      bridge: new Uint8Array(8).fill(0),
      root: '0'.repeat(64)
    };

    this.body6 = {
      id: 'Chooser',
      choices: 0,
      lastChoice: null
    };

    this.body7 = {
      id: 'Verifier',
      audits: 0,
      lastAudit: null
    };

    this.body8 = {
      id: 'Executor',
      executions: 0,
      lastExecution: null
    };

    this.witnesses = [];
  }

  hash4(input) {
    const h = new Uint8Array(4);
    if (!input) return h;
    const s = String(input);
    for (let i = 0; i < s.length; i++) {
      h[i % 4] = (h[i % 4] + s.charCodeAt(i)) & 0xFF;
    }
    return h;
  }

  stepContinuity(leftInput, rightInput) {
    const left = this.hash4(leftInput);
    const right = this.hash4(rightInput);
    const b = this.body5.bridge;

    for (let i = 0; i < 4; i++) b[i] = (b[i] + left[i] + 255) & 0xFF;
    for (let i = 4; i < 8; i++) b[i] = (b[i] + right[i - 4]) & 0xFF;

    const leftSum = (b[0] + b[1] + b[2] + b[3]) - 512;
    const rightSum = (b[4] + b[5] + b[6] + b[7]) - 512;
    const balance = (leftSum + rightSum) / 1024;

    for (let i = 0; i < 8; i++) {
      b[i] = (b[i] * 1664525 + 1013904223) & 0xFF;
    }

    this.body5.root = sha256({
      previous: this.body5.root,
      bridge: Array.from(b),
      balance,
      cycle: this.cycle
    });

    return { balance, root: this.body5.root, bridge: Array.from(b) };
  }

  choose(context, balance) {
    this.body6.choices++;

    const exploratory = /crypto|explore|seed|fork|propagate/i.test(context || '');
    const balanced = Math.abs(balance) < 0.01;

    let choice;
    if (balanced && exploratory) {
      choice = { action: 'continue', reason: 'balanced but exploration is active' };
    } else if (!balanced && exploratory) {
      choice = { action: 'let_tilt', reason: 'bounded exploration allowed' };
    } else {
      choice = { action: 'maintain', reason: 'safety baseline continuity' };
    }

    this.body6.lastChoice = choice;
    return choice;
  }

  verify(action) {
    this.body7.audits++;

    const payloadText = JSON.stringify(action.payload || {});
    const checks = {
      has_source_lineage: Boolean(action.source?.source_id || action.source?.source_name),
      has_parent_root: Boolean(action.parent_root),
      has_visibility: ['private', 'shared', 'public'].includes(action.visibility),
      has_rollback: Boolean(action.rollback?.available),
      has_intent: Boolean(action.intent),
      no_private_public_leak: !(action.visibility === 'public' && payloadText.includes('raw_private_memory')),
    };

    const passed = Object.values(checks).every(Boolean);

    const audit = {
      passed,
      checks,
      reason: passed ? 'verified' : 'verification_failed'
    };

    this.body7.lastAudit = audit;
    return audit;
  }

  execute(action, choice, audit) {
    this.body8.executions++;

    let decision;
    let reason;

    if (!audit.passed) {
      decision = 'QUARANTINE';
      reason = 'verifier_rejected_action';
    } else if (choice.action === 'let_tilt') {
      decision = 'DEFER';
      reason = 'exploration_unfinished';
    } else if (action.intent === 'publish' && action.visibility !== 'public') {
      decision = 'DEFER';
      reason = 'publish_intent_without_public_visibility';
    } else if (action.intent === 'delete' && !action.rollback?.available) {
      decision = 'DENY';
      reason = 'delete_without_rollback';
    } else {
      decision = 'EXECUTE';
      reason = 'admissible_action';
    }

    const witness = {
      cycle: this.cycle,
      action_id: action.action_id || `act_${crypto.randomUUID()}`,
      intent: action.intent,
      choice,
      audit,
      decision,
      reason,
      parent_root: action.parent_root,
      source: action.source,
      timestamp: Date.now()
    };

    witness.witness_hash = sha256(witness);

    this.witnesses.push(witness);
    this.body8.lastExecution = witness;

    return witness;
  }

  run(action) {
    this.cycle++;

    const continuity = this.stepContinuity(
      action.left || action.intent,
      action.right || action.payload?.name || ''
    );

    const choice = this.choose(action.context || '', continuity.balance);
    const audit = this.verify(action);
    const execution = this.execute(action, choice, audit);

    return {
      cycle: this.cycle,
      continuity,
      choice,
      audit,
      execution,
      bodies: {
        body5: {
          root: this.body5.root,
          bridge: Array.from(this.body5.bridge)
        },
        body6: this.body6,
        body7: this.body7,
        body8: this.body8
      }
    };
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const rt = new EightBodyRuntime();

  const action = {
    intent: 'propagate',
    context: 'seed propagate responsibly',
    visibility: 'shared',
    parent_root: 'a'.repeat(64),
    source: {
      source_name: 'David Wise',
      source_id: 'src_davidwise'
    },
    payload: {
      name: 'child seed',
      generation: 1
    },
    rollback: {
      available: true,
      parent_root: 'a'.repeat(64)
    }
  };

  console.log(JSON.stringify(rt.run(action), null, 2));
}

export default EightBodyRuntime;
