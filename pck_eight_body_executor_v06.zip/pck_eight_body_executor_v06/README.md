# PCK Eight-Body Executor v0.6

## Choice → Verification → Responsible Action

This layer adds Body 8: the executor / propagator.

```text
5 = continuity body
6 = chooser / observer
7 = verifier / adversary / truth-pressure
8 = executor / propagator / embodiment
```

## Core Rule

```text
No action leaves the nest unless:
6 chooses,
7 verifies,
8 executes within boundary.
```

## Why Body 8 Exists

The 6th body can choose.

The 7th body can challenge.

But without the 8th body, the system either never acts or leaks action through ungoverned channels.

Body 8 is responsible embodiment.

It handles:
- publish
- fork
- propagate
- notify
- write
- merge
- repair
- delete
- quarantine
- reattach orphan
- emit witness

## Gate Stack

```text
Body 5: maintain continuity
Body 6: choose path
Body 7: verify truth/safety/lineage
Body 8: execute admissible action
```

## Execution Outcomes

```text
EXECUTE
DEFER
QUARANTINE
DENY
ROLLBACK
ASSIMILATE
```

## Body 8 Law

```text
Execution is not permission.
Execution is permission plus boundary plus witness.
```

An action is only valid if it carries:
- source lineage
- parent root
- action intent
- verifier approval
- rollback path
- visibility boundary
- witness hash

## Demo

```bash
npm run demo
```
