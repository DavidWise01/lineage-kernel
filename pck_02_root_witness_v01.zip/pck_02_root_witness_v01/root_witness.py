#!/usr/bin/env python3
from pathlib import Path
from typing import Any, Dict, List
import argparse, hashlib, json, time

STACK_TAG = "02/10"
COMPONENT = "ROOT_WITNESS"
VERSION = "0.1"
GENESIS_ROOT = "0" * 64

AXIOMS = [
    "A self is not a state. A self is a replayable admissible lineage.",
    "No admitted transition is trusted until it is witnessed.",
    "No child root may detach from its parent root without becoming a fork.",
    "Layer 2 may audit Layer 1 but may not invent admissibility."
]

def now():
    return time.time()

def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode("utf-8")).hexdigest()

def read_json(path: Path, default=None):
    if not path.exists():
        if default is not None:
            return default
        raise FileNotFoundError(path)
    return json.loads(path.read_text(encoding="utf-8"))

def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str), encoding="utf-8")

def append_jsonl(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, sort_keys=True, default=str) + "\n")

def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows

class RootWitness:
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.state_path = data_dir / "witness_state.json"
        self.chain_path = data_dir / "witness_chain.jsonl"
        self.audit_path = data_dir / "audit_log.jsonl"

    def init(self):
        state = {
            "stack_tag": STACK_TAG,
            "component": COMPONENT,
            "version": VERSION,
            "genesis_root": GENESIS_ROOT,
            "current_root": GENESIS_ROOT,
            "chain_root": sha256_obj({"genesis": GENESIS_ROOT, "axioms": AXIOMS}),
            "events": 0,
            "created": now(),
            "axioms": AXIOMS
        }
        write_json(self.state_path, state)
        return state

    def state(self):
        return read_json(self.state_path, self.init())

    def validate_layer1(self, layer1: Dict[str, Any], expected_previous=None):
        checks = {
            "is_layer1": layer1.get("stack_tag") == "01/10",
            "component_ok": layer1.get("component") == "ADMISSIBILITY_ENGINE",
            "admissible": layer1.get("admissible") is True,
            "decision_ok": layer1.get("decision") in ("ALLOW", "HEAL"),
            "previous_root_present": isinstance(layer1.get("previous_root"), str) and len(layer1.get("previous_root", "")) == 64,
            "new_root_present": isinstance(layer1.get("new_root"), str) and len(layer1.get("new_root", "")) == 64,
            "previous_matches_expected": True if expected_previous is None else layer1.get("previous_root") == expected_previous,
        }
        accepted = all(checks.values())
        if not checks["previous_matches_expected"]:
            reason = "previous_root_does_not_match_current_witness_root"
        elif not checks["admissible"]:
            reason = "layer1_result_not_admissible"
        elif not checks["decision_ok"]:
            reason = "layer1_decision_not_allow_or_heal"
        elif not checks["is_layer1"] or not checks["component_ok"]:
            reason = "not_valid_layer1_result"
        elif not checks["new_root_present"]:
            reason = "missing_new_root"
        else:
            reason = "accepted"
        return {"accepted": accepted, "reason": reason, "checks": checks}

    def append_layer1_result(self, layer1):
        state = self.state()
        validation = self.validate_layer1(layer1, expected_previous=state["current_root"])
        event = {
            "stack_tag": STACK_TAG,
            "component": COMPONENT,
            "version": VERSION,
            "timestamp": now(),
            "index": state["events"] + 1,
            "layer1_hash": sha256_obj(layer1),
            "layer1": layer1,
            "validation": validation,
            "previous_chain_root": state["chain_root"],
        }

        if validation["accepted"]:
            event["witness_hash"] = sha256_obj({
                "previous_chain_root": state["chain_root"],
                "previous_root": layer1.get("previous_root"),
                "new_root": layer1.get("new_root"),
                "layer1_hash": event["layer1_hash"],
                "index": event["index"]
            })
            state["current_root"] = layer1["new_root"]
            state["chain_root"] = sha256_obj({
                "previous_chain_root": state["chain_root"],
                "witness_hash": event["witness_hash"],
                "new_root": layer1["new_root"]
            })
            state["events"] += 1
            state["updated"] = now()
            write_json(self.state_path, state)
            append_jsonl(self.chain_path, event)
        else:
            event["witness_hash"] = sha256_obj({"rejected": validation, "layer1_hash": event["layer1_hash"]})
            append_jsonl(self.audit_path, event)

        return {
            "accepted": validation["accepted"],
            "reason": validation["reason"],
            "event_index": event["index"],
            "current_root": state["current_root"],
            "chain_root": state["chain_root"],
            "witness_hash": event["witness_hash"]
        }

    def verify_chain(self):
        state = self.state()
        chain = read_jsonl(self.chain_path)
        current_root = GENESIS_ROOT
        chain_root = sha256_obj({"genesis": GENESIS_ROOT, "axioms": AXIOMS})
        errors = []

        for expected_index, event in enumerate(chain, 1):
            layer1 = event.get("layer1", {})
            validation = self.validate_layer1(layer1, expected_previous=current_root)
            if not validation["accepted"]:
                errors.append({"index": expected_index, "error": validation["reason"], "checks": validation["checks"]})
                break
            expected_witness_hash = sha256_obj({
                "previous_chain_root": chain_root,
                "previous_root": layer1.get("previous_root"),
                "new_root": layer1.get("new_root"),
                "layer1_hash": sha256_obj(layer1),
                "index": event.get("index")
            })
            if event.get("witness_hash") != expected_witness_hash:
                errors.append({"index": expected_index, "error": "witness_hash_mismatch"})
                break
            current_root = layer1["new_root"]
            chain_root = sha256_obj({
                "previous_chain_root": chain_root,
                "witness_hash": expected_witness_hash,
                "new_root": current_root
            })

        state_matches = state.get("current_root") == current_root and state.get("chain_root") == chain_root and state.get("events") == len(chain)
        return {
            "ok": not errors and state_matches,
            "events": len(chain),
            "computed_current_root": current_root,
            "stored_current_root": state.get("current_root"),
            "computed_chain_root": chain_root,
            "stored_chain_root": state.get("chain_root"),
            "state_matches": state_matches,
            "errors": errors
        }

    def audit_layer1_retroactive(self, layer1):
        chain = read_jsonl(self.chain_path)
        known_roots = {GENESIS_ROOT}
        for ev in chain:
            l1 = ev.get("layer1", {})
            if l1.get("new_root"):
                known_roots.add(l1["new_root"])
        validation = self.validate_layer1(layer1, expected_previous=None)
        prev = layer1.get("previous_root")
        if not validation["accepted"]:
            classification = "INVALID_LAYER1"
        elif prev in known_roots:
            classification = "KNOWN_LINEAGE_ATTACHABLE"
        else:
            classification = "ORPHAN_OR_FORK"
        rec = {
            "type": "retroactive_layer1_audit",
            "classification": classification,
            "previous_root": prev,
            "new_root": layer1.get("new_root"),
            "layer1_hash": sha256_obj(layer1),
            "validation": validation,
            "timestamp": now()
        }
        append_jsonl(self.audit_path, rec)
        return rec

    def export_proof(self):
        state = self.state()
        verify = self.verify_chain()
        proof = {
            "stack_tag": STACK_TAG,
            "component": COMPONENT,
            "version": VERSION,
            "state": state,
            "verification": verify,
            "exported": now(),
            "axioms": AXIOMS
        }
        proof["proof_hash"] = sha256_obj(proof)
        out = self.data_dir / "root_witness_proof.json"
        write_json(out, proof)
        return {"path": str(out), "proof_hash": proof["proof_hash"], "ok": verify["ok"]}

def demo_layer1():
    return {
        "stack_tag": "01/10",
        "component": "ADMISSIBILITY_ENGINE",
        "version": "0.1",
        "admissible": True,
        "decision": "ALLOW",
        "reason": "transition_admissible",
        "previous_root": GENESIS_ROOT,
        "new_root": sha256_obj({"demo": "new_root"}),
        "phase": "burrow",
        "checks": {"root_present": True, "delta_bounded": True, "phase_intent_compatible": True},
        "timestamp": now()
    }

def main():
    parser = argparse.ArgumentParser(description="PCK 02/10 Root Witness")
    parser.add_argument("command", choices=["init", "append", "verify", "audit", "export", "demo"])
    parser.add_argument("file", nargs="?")
    parser.add_argument("--data", default=".pck_root_witness")
    args = parser.parse_args()
    rw = RootWitness(Path(args.data))
    if args.command == "init":
        result = rw.init()
    elif args.command == "append":
        result = rw.append_layer1_result(read_json(Path(args.file)))
    elif args.command == "verify":
        result = rw.verify_chain()
    elif args.command == "audit":
        result = rw.audit_layer1_retroactive(read_json(Path(args.file)))
    elif args.command == "export":
        result = rw.export_proof()
    else:
        rw.init()
        result = rw.append_layer1_result(demo_layer1())
        result["verify"] = rw.verify_chain()
    print(json.dumps(result, indent=2, sort_keys=True, default=str))

if __name__ == "__main__":
    main()
