# Layer 2 Critique Against Layer 1

Layer 1 is forward-looking:

```text
Should this transition be admitted?
```

Layer 2 is backward-looking:

```text
Did admitted transitions actually preserve lineage?
```

## Do we need retroactive look back to 1?

Yes.

Root Witness needs to retroactively inspect Layer 1 results because:

1. Layer 1 output files can be edited.
2. Orphaned Layer 1 results may appear later.
3. A transition may be admissible locally but detached historically.
4. Bugs in Layer 1 root calculation need detection.
5. Forks need classification.

## Boundary

Layer 2 cannot invent admissibility.

It can say:

```text
this Layer 1 result attaches
this Layer 1 result does not attach
this Layer 1 result was tampered
```

But it should not decide a forbidden transition is allowed.

Layer 1 = gate.
Layer 2 = witness.
