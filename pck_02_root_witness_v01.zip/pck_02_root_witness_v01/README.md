# PCK 02/10 — Root Witness v0.1

Layer 1 decides whether a transition is admissible.
Layer 2 proves that admitted transitions form a continuous self.

Core law:

```text
A self is not a state. A self is a replayable admissible lineage.
```

## Commands

```bash
python root_witness.py demo
python root_witness.py init
python root_witness.py append examples/layer1_allow.json
python root_witness.py verify
python root_witness.py audit examples/layer1_allow.json
python root_witness.py export
```

## Relationship to 01/10

01/10 = gate.

02/10 = witness.

01 asks:

```text
Should this transition be admitted?
```

02 asks:

```text
Did admitted transitions actually preserve lineage?
```

Yes: 02 needs a retroactive look back to 01 for audit, orphan detection, and tamper detection.
